package com.example.lab3_assignment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
